
$( document ).ready(function() {
    console.log( "ready!" );
    // hide app cards per configuration on server
    if ($("#activeApps").length) {
        const activeApps = $("#activeApps").val().split(",");
        console.log("activeApps", activeApps);
        $("div[id$='-card']").each(function () {
            const app = $(this).attr('id').split("-")[0];
            if (!activeApps.includes(app)) {
                console.log("hide", app);
                $(this).hide();
            }
        });
    }
    // handle jump page
    else if ($("#jumpTo").length) {
        const appConfigs = $("#jumpTo").text().split("|");
        console.log("configs",appConfigs);
        if (appConfigs[0] === "Browser") {
            loginBrowser(appConfigs[2],appConfigs[3],appConfigs[5],appConfigs[6],'_self');
        }
        else if (appConfigs[0] === "Bloom") {
            loginBloom(appConfigs[2],appConfigs[3],appConfigs[5],appConfigs[6],appConfigs[4],'_self');
        }
        else {
            console.log("Coming Soon - generic login!");
        }
    }
});

// login to bloom with the saml tokens
loginBloom = function(protocol, port, user, password, expires, win) {
  if (checkToken(password) === true) {
    var database = protocol + "://" + window.location.hostname + ":" + port;
    console.log("database::" + database + ", expires::" + expires);
    var creds = {
      "host": database,
      "username": user,
      "password": password,
      "expiresAt": expires
    };
    localforage.setItem('neo4j.bloom.credentials', creds).then(function (value) {
      console.log("Credentials Res:",value);
      var target = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ":" + window.location.port : "") + "/bloom/";
      console.log("Bloom target",target);
      window.open(target, win);
    }).catch(function(err) {
      console.error(err);
    });
  }
};

loginApp = function() {
    
}

// linkurious handles the saml process itself.
loginLink = function(token) {
  if (checkToken(token) === true) {
    var target = window.location.protocol + "//" + window.location.hostname + "/link/api/auth/sso/login?redirect_url=" + encodeURI(window.location.protocol+"//"+window.location.hostname+"/link/dashboard");
    window.open(target, '_blank');
  }
};

logout = function(bloom_enabled, username, session) {
    if (bloom_enabled != "disabled") {
        localforage.removeItem('neo4j.bloom.credentials').then(function() {
            console.log("Removed Bloom Credentials");
        }).catch(function(err) {
            console.error(err);
        });
    }
    // clear browser cached login info
    localStorage.removeItem("neo4j.connections");
    localStorage.removeItem("holder");
    
    $.post("/saml/auth/logoutreq", {username: username, session: session}, function(result) {
       console.log("Logout::", result);
       window.location = result;
    });
};

loginBrowser = function(protocol, boltPort, user, password, win) {
    if (checkToken(password) === true) {
      //var connectURL = protocol + "://" + user + ":" + password + "@" + window.location.hostname + ":" + boltPort;
      var baseURL = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ":" + window.location.port : "") + "/browser/";
      //var target = baseURL + "?connectURL=" + connectURL;
      const target = baseURL;
      localStorage.setItem("neo4j.connections",JSON.stringify(getBrowserConnectionObject(protocol, window.location.hostname, boltPort, user, password, null)));
      localStorage.setItem("holder", JSON.stringify(getBrowserConnectionObject(protocol, window.location.hostname, boltPort, user, password, null)));
      window.open(target, win);
    }
};

checkToken = function(token) {
    const saml = window.atob(token);
    console.log("saml",saml);
    const samlobj = $.parseXML(saml);
    const after = $(samlobj).nodeFilter('Conditions').attr('NotOnOrAfter');
    const before = $(samlobj).nodeFilter('Conditions').attr('NotBefore');
    //const after = $(saml).find('Conditions').attr('NotOnOrAfter');
    //const before = $(saml).find('Conditions').attr('NotBefore');
    const after_ms = Date.parse(after);
    const before_ms = Date.parse(before);
    const now = Date.now();
    console.log("after", after,"before",before,"now",now);
    if (now < before_ms || now > after_ms) {
        console.log("token is not valid");
        const b = $("<button type=\"button\" class=\"btn btn-secondary\" style=\"margin-left: 40px;\" onclick=\"javascript:window.location.href='/browser-saml/auth/req'; return false;\">Login</button>");
        const w = $("<div id=\"alert\" class=\"alert alert-warning\" role=\"alert\"></div>").text("Your authenticated session is expired!");
        w.append(b);
        $("#messages").append(w);
        return false;
    }
    return true;
};

getBrowserConnectionObject = function(protocol, host, port, user, password, db) {
  return connectionObject = {
    allConnectionIds:["$$discovery"],
    connectionsById: {
      $$discovery: {
        password:password,
        id:"$$discovery",
        name:"$$discovery",
        type:protocol,
        db:db,
        host:protocol + "://" + host + ":" + port,
        username:user,
        authenticationMethod:"NATIVE",
        authEnabled:true
    }
  },
  activeConnection:"$$discovery",
  connectionState:1,
  lastUpdate:Date.now(),
  useDb:null
  };
};
