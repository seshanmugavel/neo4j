package org.neo4j.field.auth;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.apache.commons.io.IOUtils;

public class TemplateResolver {
    
    private InputStream templateFile = null;
    private String templateFileStr = null;
    private Map<String,String> templateData = null;
    private LoggingFacade log = null;
   
    public TemplateResolver(InputStream file) {
        setTemplate(file);
    }
    
    public TemplateResolver(InputStream file, Map<String,String>vals) {
        setTemplate(file);
        setTemplateVals(vals);
    }
    
    public TemplateResolver(InputStream file, Map<String,String>vals, org.neo4j.logging.Log x) {
        setTemplate(file);
        setTemplateVals(vals);
        setLogger(x);
    }
    
    public final void setLogger(org.neo4j.logging.Log x) {
        log = new LoggingFacade(x);
    }
    
    public final void setTemplate(InputStream t) {
        this.templateFile = t;
        try {
            this.templateFileStr = IOUtils.toString(t, StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.error("Error loading template:" + e);
        }
    }
    
    public String getTemplate() {
        return this.templateFileStr;
    }
    
    public final void setTemplateVals(Map<String,String>vals) {
        this.templateData = vals;
    }
    
    public String resolveTemplate() {
        String r = this.templateFileStr;        
        for (Map.Entry<String, String> rep : this.templateData.entrySet()) {
            r = r.replace("${" + rep.getKey() + "}", rep.getValue());
        }
        return r;
    }
}
