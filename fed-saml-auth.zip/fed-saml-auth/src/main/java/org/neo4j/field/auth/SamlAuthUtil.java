package org.neo4j.field.auth;

import java.util.ArrayList;
import java.util.List;
import org.opensaml.core.xml.XMLObject;
import org.opensaml.core.xml.schema.XSString;
import org.opensaml.core.xml.schema.impl.XSAnyImpl;

public class SamlAuthUtil {
    
    public static ArrayList<String> getAttributeValues(List<XMLObject> vals) {
        ArrayList<String> list = new ArrayList<>();
        vals.forEach((o) -> {
            list.add(getAttributeValue(o));
        });
        return list;
    }
    
    public static String getAttributeValue(XMLObject attributeValue) {
        return attributeValue == null
                ? null
                : attributeValue instanceof XSString
                        ? getStringAttributeValue((XSString) attributeValue)
                        : attributeValue instanceof XSAnyImpl
                                ? getAnyAttributeValue((XSAnyImpl) attributeValue)
                                : attributeValue.toString();
    }

    private static String getStringAttributeValue(XSString attributeValue) {
        return attributeValue.getValue();
    }

    private static String getAnyAttributeValue(XSAnyImpl attributeValue) {
        return attributeValue.getTextContent();
    }

}
