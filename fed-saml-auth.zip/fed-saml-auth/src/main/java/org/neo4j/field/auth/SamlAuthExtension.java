package org.neo4j.field.auth;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;
import org.apache.http.client.utils.URIBuilder;
import org.neo4j.configuration.Config;
import org.neo4j.configuration.connectors.BoltConnector;
import org.opensaml.saml.saml2.core.Assertion;
import org.neo4j.logging.Log;

@Path( "/auth" )
public class SamlAuthExtension {
    /**
     * Get a SAMLv2 metadata descriptor for this SP.
     * @return 
     */
    @GET
    @Path( "/metadata" )
    @Produces ( MediaType.APPLICATION_XML )
    public Response getSPMetadata() {
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance();
            SamlRequest r = new SamlRequest();
            String m = r.generateMetaData(y, false, false).getValue();
            return Response.status(Status.OK).entity(m).build();
        } catch (IOException e) {
            e.printStackTrace();
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }  
    }
    
    @GET
    @Path("/{a:browser|browser/bloom|bloom}")
    @Produces (MediaType.APPLICATION_XML )
    public Response getBrowserAuth(@PathParam("a") String a, @Context HttpHeaders hdrs, @Context UriInfo uriInfo, @Context Log log, @Context Config c) {
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance();
            SamlRequest r = new SamlRequest();
            log.info("URI::" + uriInfo.getRequestUri().toASCIIString() + ",INCOMING::" + a);
            URIBuilder rs = new URIBuilder(uriInfo.getRequestUri());
            final List<String> pxyHeaders = hdrs.getRequestHeader("X-Forwarded-Proto");
            if (pxyHeaders != null && pxyHeaders.size() >= 1) {
                rs.setScheme(hdrs.getRequestHeader("X-Forwarded-Proto").get(0));
            }
            rs.setPath("/" + a + "/");
            String req = r.generateSAMLRequest(y, true);  // IDP expects compressed
            String loc = new StringBuilder().append(y.getProperty("saml_idp_request_uri")).append("?").append(y.getProperty("saml_idp_request_param"))
                    .append("=").append(req).append("&RelayState=").append(rs.toString()).toString();
            return Response.temporaryRedirect(URI.create(loc)).build();
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error", e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }

    }
  
    /**
     * process SAML response from IDP.
     * @param formParams
     * @param log
     * @param c
     * @return 
     */
    @POST
    @Path ("/resp" )
    @Produces ("text/html; charset=UTF-8")
    public Response authResponse(MultivaluedMap<String, String> formParams, @Context Log log, @Context Config c) {
        // TODO = check in responseto
        // put a logout button on there.
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance();
            Map<String, String> templateVals = new HashMap<String,String>(); 
            templateVals.put("basepath", y.getProperty("saml_base_path", "/saml"));
            SamlAuthService se = new SamlAuthService();
            se.setIdpPublicKey((FileInputStream)y.getFilePropertyAsStream("saml_x509_certificate"));
            se.init(y);
            se.setLogger(log);
            String xe = y.getProperty("saml_idp_response_param");
            Assertion a = se.decodeSamlResponse(formParams.getFirst(xe), true);
            if (a != null) {
                SamlAuthUser u = se.parseResponse(a);
                log.info("FORM::" + formParams);
                log.info("USER::" + u.getUser());
                if (formParams.containsKey("RelayState")) {
                    String app = resolveRelayPath(formParams.getFirst("RelayState"),log);
                    templateVals.put("appName", app);
                    templateVals.put("username", u.getUser());
                    templateVals.put("token", formParams.getFirst(xe));
                    int p = c.get(BoltConnector.listen_address).getPort();
                    templateVals.put("boltPort", Integer.toString(p));
                    templateVals.put("protocol", y.getProperty("saml_bloom_access_protocol", "bolt"));
                    templateVals.put("expires", String.valueOf(u.getUntil().getMillis()));
                    templateVals.put("appUrl", formParams.getFirst("RelayState"));
                    log.info("Template::" + templateVals.toString());
                    TemplateResolver t = new TemplateResolver(y.getFilePropertyResourceAsStream("saml_jump_template", "/templates/jump.html"),templateVals,log);
                    return Response.status(Status.OK).entity(t.resolveTemplate()).build();
                }
                else  {
                    templateVals.put("username", u.getUser());
                    templateVals.put("token", formParams.getFirst(xe));
                    templateVals.put("email", Optional.ofNullable(u.getEmail()).orElse("Not Available"));
                    templateVals.put("userroles", String.join(",",Optional.ofNullable(u.getRoles()).orElse(new ArrayList<>())));
                    int p = c.get(BoltConnector.listen_address).getPort();
                    templateVals.put("boltPort", Integer.toString(p));
                    templateVals.put("protocol", y.getProperty("saml_bloom_access_protocol", "bolt"));
                    templateVals.put("expires", String.valueOf(u.getUntil().getMillis()));
                    templateVals.put("endvalid", u.getUntil().toString());
                    templateVals.put("session", u.getSession());
                    try {
                        c.getSetting("neo4j.bloom.license_file");
                        templateVals.put("bloomDisabled", "");  
                    } catch (IllegalArgumentException e1) {
                        try {
                            c.getSetting("neo4j_bloom_license_file"); // docker
                            templateVals.put("bloomDisabled", "");
                        } catch (IllegalArgumentException e2) {
                            templateVals.put("bloomDisabled", "disabled");
                        }
                    }          
                    templateVals.put("logoutURI", Optional.ofNullable(y.getProperty("saml_logout_uri")).orElse("NA"));
                    templateVals.put("logoutDisabled", Optional.ofNullable(y.getProperty("saml_logout_uri")).orElse("disabled"));
                    templateVals.put("activeApps", y.getProperty("saml_apps_enabled", "bloom,linkurious,browser,logout"));
                    TemplateResolver t = new TemplateResolver(y.getFilePropertyResourceAsStream("saml_success_template", "/templates/success.html"),templateVals,log);
                    return Response.status(Status.OK).entity(t.resolveTemplate()).build();
                }
            }
            // error handler
            org.opensaml.saml.saml2.core.Status s = se.getStatus();
            templateVals.put("message", s.getStatusMessage().getMessage());
            TemplateResolver te = new TemplateResolver(y.getFilePropertyResourceAsStream("saml_error_template", "/templates/error.html"),templateVals,log);
            return Response.status(Status.OK).entity(te.resolveTemplate()).build();
            
        } catch (Exception e) {
            System.out.println("ERROR" + e);
            e.printStackTrace();
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    private String resolveRelayPath(String relay, Log log) throws URISyntaxException {
        URIBuilder u = new URIBuilder(relay);
        log.info("Builder::" + u.getPath());
        if (u.getPath().contains("bloom")) {
            return "Bloom";
        }
        else if (u.getPath().contains("/browser")) {
            return "Browser";
        }
        return "App";
    }
    
    /**
     * send authnrequest to IDP.
     * @return 
     */
    @GET
    @Path("/req")
    @Produces("text/html; charset=UTF-8")
    public Response auth(@Context Log log) {
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance();
            SamlRequest r = new SamlRequest();
            String req = r.generateSAMLRequest(y, true);  // IDP expects compressed
            String loc = new StringBuilder().append(y.getProperty("saml_idp_request_uri")).append("?").append(y.getProperty("saml_idp_request_param")).append("=").append(req).toString();
            return Response.temporaryRedirect(URI.create(loc)).build();
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error", e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    /**
     * send a logout request
     */
    @POST
    @Path("/logoutreq")
    @Produces("text/html; charset=UTF-8")
    public Response logoutReq(MultivaluedMap<String, String> formParams, @Context Log log) {
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance();
            SamlRequest r = new SamlRequest();
            r.setCreds((FileInputStream)y.getFilePropertyAsStream("saml_private_key"), (FileInputStream)y.getFilePropertyAsStream("saml_x509_certificate"));
            String user = formParams.getFirst("username");
            String session = formParams.getFirst("session");
            String lr = r.generateSAMLLogoutReq(y, true, user, session);
            String loc = new StringBuilder().append(y.getProperty("saml_idp_logout_uri"))
              .append("?").append(y.getProperty("saml_idp_logout_param")).append("=").append(lr)
              .append("&ReturnTo=").append(y.getProperty("saml_sp_logout_uri")).toString();
            //return Response.temporaryRedirect(URI.create(loc)).build();
            return Response.ok(loc).build();
        } catch (Exception e) {
            e.printStackTrace();
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    /**
     * handle logout response
     */
    @GET
    @Path("/logout")
    @Produces("text/html; charset=UTF-8")
    public Response logoutResp(@Context Log log) {
        return baseResponse("You have been logged out!", log);
    }
    
    /**
     * handle logout response
     */
    @GET
    @Path("/login")
    @Produces("text/html; charset=UTF-8")
    public Response login(@Context Log log) {
        return baseResponse("", log);
    }
    
    private Response baseResponse(String message, Log log) {
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance();
            Map<String, String> templateVals = new HashMap<String, String>();
            templateVals.put("message", message);
            templateVals.put("basepath", y.getProperty("saml_base_path", "/saml"));
            TemplateResolver t = new TemplateResolver(y.getFilePropertyResourceAsStream("saml_login_template", "/templates/login.html"),templateVals,log);
            return Response.status(Status.OK).entity(t.resolveTemplate()).build();
        } catch (Exception e) {
            System.out.println("ERROR" + e);
            log.error("ERROR::", e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }
}
