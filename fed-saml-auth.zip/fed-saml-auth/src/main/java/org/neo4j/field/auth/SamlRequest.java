package org.neo4j.field.auth;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.AbstractMap.SimpleEntry;
import java.util.Base64;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import javax.xml.namespace.QName;
import net.shibboleth.utilities.java.support.xml.SerializeSupport;
import org.apache.commons.io.IOUtils;
import org.apache.xml.security.c14n.Canonicalizer;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.joda.time.DateTime;
import org.opensaml.core.xml.XMLObjectBuilderFactory;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.Marshaller;
import org.opensaml.core.xml.io.MarshallerFactory;
import org.opensaml.core.xml.io.MarshallingException;
import org.opensaml.saml.common.SAMLVersion;
import org.opensaml.saml.common.xml.SAMLConstants;
import org.opensaml.saml.saml2.core.AuthnContextClassRef;
import org.opensaml.saml.saml2.core.AuthnContextComparisonTypeEnumeration;
import org.opensaml.saml.saml2.core.AuthnRequest;
import org.opensaml.saml.saml2.core.Issuer;
import org.opensaml.saml.saml2.core.LogoutRequest;
import org.opensaml.saml.saml2.core.NameID;
import org.opensaml.saml.saml2.core.NameIDPolicy;
import org.opensaml.saml.saml2.core.RequestedAuthnContext;
import org.opensaml.saml.saml2.core.SessionIndex;
import org.opensaml.saml.saml2.metadata.AssertionConsumerService;
import org.opensaml.saml.saml2.metadata.ContactPerson;
import org.opensaml.saml.saml2.metadata.ContactPersonTypeEnumeration;
import org.opensaml.saml.saml2.metadata.EmailAddress;
import org.opensaml.saml.saml2.metadata.EntityDescriptor;
import org.opensaml.saml.saml2.metadata.GivenName;
import org.opensaml.saml.saml2.metadata.KeyDescriptor;
import org.opensaml.saml.saml2.metadata.NameIDFormat;
import org.opensaml.saml.saml2.metadata.SPSSODescriptor;
import org.opensaml.saml.saml2.metadata.SingleLogoutService;
import org.opensaml.saml.saml2.metadata.SurName;
import org.opensaml.security.SecurityException;
import org.opensaml.security.credential.CredentialSupport;
import org.opensaml.security.credential.UsageType;
import org.opensaml.security.x509.BasicX509Credential;
import org.opensaml.xmlsec.keyinfo.KeyInfoGenerator;
import org.opensaml.xmlsec.keyinfo.impl.X509KeyInfoGeneratorFactory;
import org.opensaml.xmlsec.signature.KeyInfo;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.X509Data;
import org.opensaml.xmlsec.signature.support.SignatureConstants;
import org.opensaml.xmlsec.signature.support.SignatureException;
import org.opensaml.xmlsec.signature.support.Signer;
import org.w3c.dom.Element;


public class SamlRequest {
    private BasicX509Credential cred = null;
    private LoggingFacade log = null;
    
    public void setLogger(com.neo4j.server.security.enterprise.auth.plugin.api.AuthProviderOperations.Log x) {
        log = new LoggingFacade(x);
    }

    public void setLogger() {
        log = new LoggingFacade(SamlAuthService.class);
    }
    
    /**
     * pull in the credentials from separate PEM-encoded files.  same files as those generated for Neo4j.
     * @param keyFile
     * @param certFile
     * @throws FileNotFoundException
     * @throws CertificateException 
     */
    public void setCreds(FileInputStream keyFile, FileInputStream certFile) throws FileNotFoundException, CertificateException {
        CertificateFactory f = CertificateFactory.getInstance("X.509");
        X509Certificate c = (X509Certificate)f.generateCertificate(certFile);
        BufferedInputStream bis = new BufferedInputStream(keyFile);
        try {
            String contents = IOUtils.toString(keyFile, StandardCharsets.UTF_8);
            PemReader pemReader = new PemReader(new StringReader(contents));
            PemObject pemObject = pemReader.readPemObject();
            byte[] pemContent = pemObject.getContent();
            pemReader.close();
            PKCS8EncodedKeySpec encodedKeySpec = new PKCS8EncodedKeySpec(pemContent);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA", "BC");
            PrivateKey pk = keyFactory.generatePrivate(encodedKeySpec);
            this.cred = CredentialSupport.getSimpleCredential(c, pk);
	} catch (IOException e) {
            e.printStackTrace();
	} catch (NoSuchAlgorithmException ae) {
            ae.printStackTrace();
        } catch (InvalidKeySpecException ex) {
            ex.printStackTrace();
        } catch (NoSuchProviderException ex) {
            ex.printStackTrace();
        }
    }
    
  public String generateSAMLRequest(SamlAuthConfig config, boolean compress) throws MarshallingException, IOException {
        AuthnRequest authRequest = buildAuthenticationRequest(config);
        MarshallerFactory mf = XMLObjectProviderRegistrySupport.getMarshallerFactory();
        Marshaller m = mf.getMarshaller(authRequest);
        Element authDOM = m.marshall(authRequest);
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        SerializeSupport.writeNode(authDOM, b);
        String messageXML = new String(b.toByteArray());
        if (compress == true) {
            Deflater deflater = new Deflater(Deflater.DEFLATED, true);
            ByteArrayOutputStream bb = new ByteArrayOutputStream();
            DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(bb, deflater);
            deflaterOutputStream.write(messageXML.getBytes());
            deflaterOutputStream.close();
            String s = Base64.getEncoder().encodeToString(bb.toByteArray());
            return URLEncoder.encode(s, "UTF-8");
        }
        String s = Base64.getEncoder().encodeToString(messageXML.getBytes());
        return URLEncoder.encode(s, "UTF-8");
    }
    
    public String generateSAMLLogoutReq(SamlAuthConfig config, boolean compress, String user, String session) throws MarshallingException, IOException {
        LogoutRequest logoutReq = buildLogoutRequest(config, user, session);
        MarshallerFactory mf = XMLObjectProviderRegistrySupport.getMarshallerFactory();
        Marshaller m = mf.getMarshaller(logoutReq);
        Element logoutDOM = m.marshall(logoutReq);
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        SerializeSupport.writeNode(logoutDOM, b);
        String messageXML = new String(b.toByteArray());
        if (compress == true) {
            Deflater deflater = new Deflater(Deflater.DEFLATED, true);
            ByteArrayOutputStream bb = new ByteArrayOutputStream();
            DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(bb, deflater);
            deflaterOutputStream.write(messageXML.getBytes());
            deflaterOutputStream.close();
            String s = Base64.getEncoder().encodeToString(bb.toByteArray());
            return URLEncoder.encode(s, "UTF-8");
        }
        String s = Base64.getEncoder().encodeToString(messageXML.getBytes());
        return URLEncoder.encode(s, "UTF-8");
    }
  
    public AuthnRequest buildAuthenticationRequest(SamlAuthConfig config) {
        DateTime issueInstant = new DateTime();
        AuthnRequest ar = buildSAMLObject(AuthnRequest.class);
        ar.setForceAuthn(Boolean.FALSE);
        ar.setIsPassive(Boolean.FALSE);
        ar.setIssueInstant(issueInstant);
        ar.setProtocolBinding("urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST");
        //ar.setProtocolBinding(SAMLConstants.SAML2_REDIRECT_BINDING_URI);
        ar.setAssertionConsumerServiceURL(config.getProperty("saml_sp_consumer_service_url"));
        ar.setIssuer(getIssuer(config.getProperty("saml_sp_issuer_id")));
        ar.setNameIDPolicy(getNameIDPolicy(config));
        ar.setRequestedAuthnContext(getRequestedAuthnContext());
        // (GM) 09/21/2020.  bad xs:ID if it starts with a number
        ar.setID(new StringBuilder("_").append(UUID.randomUUID().toString()).toString());
        ar.setVersion(SAMLVersion.VERSION_20);
        
        if (config.getBooleanProperty("saml_sign_authn_request", false)) {
            Signature sign = buildSAMLObject(Signature.class);
            sign.setSigningCredential(cred);
            sign.setSchemaLocation("http://www.w3.org/2000/09/xmldsig#");
            sign.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA256);
            sign.setCanonicalizationAlgorithm(Canonicalizer.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);
            ar.setSignature(sign);
            try {
                XMLObjectProviderRegistrySupport.getMarshallerFactory().getMarshaller(ar).marshall(ar);
            } catch (MarshallingException e) {
                throw new RuntimeException(e);
            }
            try {
                Signer.signObject(sign);
            } catch (SignatureException e) {
                throw new RuntimeException(e);
            }
        }
        return ar;
    }
    
    private  RequestedAuthnContext getRequestedAuthnContext() {
        AuthnContextClassRef cr = buildSAMLObject(AuthnContextClassRef.class);
        cr.setAuthnContextClassRef("urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport");
        RequestedAuthnContext ra = buildSAMLObject(RequestedAuthnContext.class);
        ra.setComparison(AuthnContextComparisonTypeEnumeration.EXACT);
        ra.getAuthnContextClassRefs().add(cr);
        return ra;
    }
    
    private NameIDPolicy getNameIDPolicy(SamlAuthConfig conf) {
        NameIDPolicy np = buildSAMLObject(NameIDPolicy.class);
        np.setAllowCreate(Boolean.TRUE);
        String format = conf.getProperty("saml_idp_authn_request_format", "urn:oasis:names:tc:SAML:2.0:nameid-format:persistent");
        np.setFormat(format);
        return np;
    }
    
    private Issuer getIssuer(final String issuerName) {
        Issuer i = buildSAMLObject(Issuer.class);
        i.setValue(issuerName);
        return i;
    }
        
    private <T> T buildSAMLObject(final Class<T> clazz) {
        T object = null;
        try {
            XMLObjectBuilderFactory builderFactory = XMLObjectProviderRegistrySupport.getBuilderFactory();
            QName defaultElementName = (QName) clazz.getDeclaredField("DEFAULT_ELEMENT_NAME").get(null);
            object = (T) builderFactory.getBuilder(defaultElementName).buildObject(defaultElementName);
        } catch (IllegalAccessException e) {
            throw new IllegalArgumentException("Could not create SAML object");
        } catch (NoSuchFieldException e) {
            throw new IllegalArgumentException("Could not create SAML object");
        }
        return object;
    }
    
    public LogoutRequest buildLogoutRequest(SamlAuthConfig config, String username, String sessionIndex) {
        DateTime issueInstant = new DateTime();
        LogoutRequest lr = buildSAMLObject(LogoutRequest.class);
        lr.setID(new StringBuilder("_").append(UUID.randomUUID().toString()).toString());
        lr.setIssuer(getIssuer(config.getProperty("saml_sp_issuer_id")));
        lr.setIssueInstant(issueInstant);
        lr.setNotOnOrAfter(new DateTime(issueInstant.getMillis() + 5 * 60 * 1000));
        lr.setDestination(config.getProperty("saml_idp_logout_uri"));
        
        NameID nid = buildSAMLObject(NameID.class);
        nid.setFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:entity");
        nid.setValue(username);
        lr.setNameID(nid);
        
        SessionIndex si = buildSAMLObject(SessionIndex.class);
        si.setSessionIndex(sessionIndex);
        lr.getSessionIndexes().add(si);
        lr.setReason("urn:oasis:names:tc:SAML:2.0:logout:user");
        
        if (config.getBooleanProperty("saml_sign_logout_request", true)) {
            Signature sign = buildSAMLObject(Signature.class);
            sign.setSigningCredential(cred);
            sign.setSchemaLocation("http://www.w3.org/2000/09/xmldsig#");
            sign.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA256);
            sign.setCanonicalizationAlgorithm(Canonicalizer.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);
            lr.setSignature(sign);
            try {
                XMLObjectProviderRegistrySupport.getMarshallerFactory().getMarshaller(lr).marshall(lr);
            } catch (MarshallingException e) {
                throw new RuntimeException(e);
            }
            try {
                Signer.signObject(sign);
            } catch (SignatureException e) {
                throw new RuntimeException(e);
            }
        }
        return lr;
    }

    public Entry<Element,String> generateMetaData(SamlAuthConfig config, boolean signAssert, boolean signAuthn) {
        EntityDescriptor ed = buildSAMLObject(EntityDescriptor.class);
        ed.setSchemaLocation("urn:oasis:names:tc:SAML:2.0:metadata");
        ed.setEntityID(config.getProperty("saml_sp_entity_id"));
        SPSSODescriptor spd = buildSAMLObject(SPSSODescriptor.class);
        spd.setWantAssertionsSigned(signAssert); 
        spd.setAuthnRequestsSigned(signAuthn);
        
        X509KeyInfoGeneratorFactory kf = new X509KeyInfoGeneratorFactory();
        kf.setEmitEntityCertificate(true);
        KeyInfoGenerator keyInfoGenerator = kf.newInstance();
        
        KeyDescriptor skd = buildSAMLObject(KeyDescriptor.class);
        skd.setUse(UsageType.SIGNING); 
        // Generating key info. The element will contain the public key. 
        // The key is used to by the IDP to verify signatures
        try {
            if (signAssert == true) {
                skd.setKeyInfo(keyInfoGenerator.generate(cred));
                spd.getKeyDescriptors().add(skd);
            }
            NameIDFormat nf = buildSAMLObject(NameIDFormat.class);
            nf.setFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:transient");
            spd.getNameIDFormats().add(nf);
            AssertionConsumerService acs0 = buildSAMLObject(AssertionConsumerService.class);
            acs0.setIndex(0);
            acs0.setBinding(SAMLConstants.SAML2_POST_BINDING_URI);
            acs0.setLocation(config.getProperty("saml_sp_consumer_service_url"));
            spd.getAssertionConsumerServices().add(acs0);
            // TODO - add other artifacts
            
            // SP LogoutService
            SingleLogoutService ls = buildSAMLObject(SingleLogoutService.class);
            ls.setBinding(SAMLConstants.SAML2_REDIRECT_BINDING_URI);
            ls.setLocation(config.getProperty("saml_sp_logout_url"));
            spd.getSingleLogoutServices().add(ls);
            
            spd.addSupportedProtocol(SAMLConstants.SAML20P_NS);
            ed.getRoleDescriptors().add(spd);
           
            // SP contact info
            ContactPerson cp = buildSAMLObject(ContactPerson.class);
            GivenName gn = buildSAMLObject(GivenName.class);
            gn.setName(config.getProperty("saml_contact_givenname", "unknown"));
            SurName sn = buildSAMLObject(SurName.class);
            sn.setName(config.getProperty("saml_contact_surname", "unknown"));
            EmailAddress em = buildSAMLObject(EmailAddress.class);
            em.setAddress(config.getProperty("saml_contact_email", "unknown"));
            cp.setGivenName(gn);
            cp.setSurName(sn);
            cp.setType(ContactPersonTypeEnumeration.TECHNICAL);
            cp.getEmailAddresses().add(em);
            ed.getContactPersons().add(cp);
            
            MarshallerFactory mf = XMLObjectProviderRegistrySupport.getMarshallerFactory();
            Marshaller m = mf.getMarshaller(ed);
            Element e = m.marshall(ed);
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            SerializeSupport.writeNode(e, b);
            String metadataXML = new String(b.toByteArray());
            return new SimpleEntry<>(e,metadataXML);
        } catch (SecurityException ex) {
            ex.printStackTrace();
            return null;
        } catch (MarshallingException ex) {
            ex.printStackTrace();
            return null;    
        } 
    }
}
