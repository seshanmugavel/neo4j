package org.neo4j.field.auth;


public class SamlAuthConstants {
    public static final String SAML_PROXY_PROTO_HEADER_NAME = "X-Forwarded-Proto";
    public static final String SAML_RELAYSTATE_URI_PARAM_NAME = "RelayState";
    
    public static final String SAML_IDP_REQUEST_URI_PROP = "saml_idp_request_uri";
    public static final String SAML_IDP_REQUEST_PARAM_PROP = "saml_idp_request_param";
    public static final String SAML_IDP_RESPONSE_PARAM_PROP = "saml_idp_response_param";
    
    public static final String SAML_SP_APP_ACCESS_PROTOCOL_PROP = "saml_bloom_access_protocol";
    
    public static final String SAML_SP_LOGOUT_URI = "saml_sp_logout_uri";
    
    public static final String SAML_SP_SUCCESS_TEMPLATE_PROP = "saml_success_template";
    public static final String SAML_SP_ERROR_TEMPLATE_PROP = "saml_error_template";
    public static final String SAML_SP_JUMP_TEMPLATE_PROP = "saml_jump_template";
    public static final String SAML_SP_LOGIN_TEMPLATE_PROP = "saml_login_template";
    
}
