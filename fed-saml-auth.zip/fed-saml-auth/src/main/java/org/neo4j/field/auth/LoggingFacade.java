package org.neo4j.field.auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * yes, this is dumb
 * TODO - rewrite this
 */
public class LoggingFacade {
    private Logger alog = null;
    private com.neo4j.server.security.enterprise.auth.plugin.api.AuthProviderOperations.Log slog = null;
    private org.neo4j.logging.Log nlog = null;
    
    public LoggingFacade(Class x) {
        alog = LoggerFactory.getLogger(x);
    }
    
    public LoggingFacade(org.neo4j.logging.Log n) {
        nlog = n;
    }
    
    public LoggingFacade(com.neo4j.server.security.enterprise.auth.plugin.api.AuthProviderOperations.Log apilog) {
        slog = apilog;
    }
    
    void debug( String message ) {
        if (slog != null) {
            slog.debug(message);
        } else if (nlog != null) {
            nlog.debug(message);
        } else {
            alog.debug(message);
        }
    }
    
    void debug( String message, Exception e ) {
        if (slog != null) {
            slog.debug(message + "::" + e.toString());
        } else if (nlog != null) {
            nlog.debug(message, e);
        } else {
            alog.debug(message, e);
        }
    }

    void info( String message ) {
        if (slog != null) {
            slog.info(message);
        } else if (nlog != null) {
            nlog.info(message);
        } else {
            alog.info(message);
        }
    }

    void info( String message, Exception e ) {
        if (slog != null) {
            slog.info(message + "::" + e.toString());
        } else if (nlog != null) {
            nlog.info(message, e);
        } else {
            alog.info(message, e);
        }
    }
        
    void warn( String message ) {
        if (slog != null) {
            slog.warn(message);
        } else if (nlog != null) {
            nlog.warn(message);
        } else {
            alog.warn(message);
        }
    }
    
    void warn( String message, Exception e ) {
        if (slog != null) {
            slog.warn(message + "::" + e.toString());
        } else if (nlog != null) {
            nlog.warn(message, e);
        } else {
            alog.warn(message, e);
        }
    }
        
    void error( String message ) {
        if (slog != null) {
            slog.error(message);
        } else if (nlog != null) {
            nlog.error(message);
        } else {
            alog.error(message);
        }
    }
    
    void error( String message, Exception e ) {
        if (slog != null) {
            slog.error(message + "::" + e.toString());
        } else if (nlog != null) {
            nlog.error(message, e);
        } else {
            alog.error(message, e);
        }
    }
}
