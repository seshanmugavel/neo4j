package org.neo4j.field.auth;

import com.neo4j.server.security.enterprise.auth.plugin.api.AuthProviderOperations;
import com.neo4j.server.security.enterprise.auth.plugin.api.AuthToken;
import com.neo4j.server.security.enterprise.auth.plugin.api.AuthenticationException;
import com.neo4j.server.security.enterprise.auth.plugin.spi.AuthInfo;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Path;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import com.neo4j.server.security.enterprise.auth.plugin.spi.AuthPlugin;
import java.nio.file.Paths;
import org.opensaml.core.config.InitializationException;
import org.opensaml.core.config.InitializationService;
import org.opensaml.saml.saml2.core.Assertion;

public class SamlAuthPlugin extends AuthPlugin.Adapter {
    private AuthProviderOperations api = null;
    private SamlAuthConfig config = null;

    @Override
    public void initialize(AuthProviderOperations authProviderOperations) {
        api = authProviderOperations;
        try {
            Path configPath = null;
            if (System.getenv("SAML_CONF_DIR") != null) {
                configPath = Paths.get(System.getenv("SAML_CONF_DIR")).resolve("saml.conf");
            }
            else {
                configPath = authProviderOperations.neo4jHome().resolve( "conf/saml.conf" );
            }
            authProviderOperations.log().info("Configuring SAML with:: " + configPath.toString());
            config = SamlAuthConfig.getInstance(configPath);
            InitializationService.initialize();
        } catch (IOException | InitializationException e) {
            api.log().error("Error configuring::" + e.toString());
        }
    }

    private Set<String> mapRoles(SamlAuthUser u) {
        Set<String> rs = new HashSet<>();
        HashMap<String, Object> m = config.getMultiProperty("saml_role_mapping");
        api.log().info("Mapping Config::" + m);
        api.log().info("Role Mapping::" + u.getRoles());
        u.getRoles().forEach(
          x -> {
            api.log().info("Role:" + x);
            if (m.get(x) != null) {
              if (m.get(x) instanceof String) {
                rs.add((String) m.get(x));
              } 
              else {
                rs.addAll((ArrayList<String>) m.get(x));
              }
            } 
            else { 
                api.log().info("No mapping for role::" + x);
            }
        });
        api.log().info("Final Role Mapping::" + rs);
        return rs;
    }
    
    @Override
    public AuthInfo authenticateAndAuthorize(AuthToken authToken) throws AuthenticationException {
        try {
            SamlAuthService service = new SamlAuthService();
            service.setIdpPublicKey((FileInputStream) config.getFilePropertyAsStream("saml_x509_certificate"));
            service.setLogger(api.log());
            service.init(config);

            // TODO - no need to decode twice!
            String samlResponse = new String(authToken.credentials());
            byte[] decode = Base64.getDecoder().decode(samlResponse);
            String decodedSAMLstr = new String(decode, "UTF-8"); // for UTF-8 encoding
            api.log().info("Response::" + decodedSAMLstr);
            if (!decodedSAMLstr.contains(":Response")) {
                api.log().info("Received a non-SAML authentication request for : " + authToken.principal());
                return null;
            }
            api.log().info("Token:: " + samlResponse);
            Assertion a = service.decodeSamlResponse(samlResponse, config.getBooleanProperty("saml_require_signature_validation"));
            if (a == null) {
                api.log().info("Assertion not validated - not authorized.");
                return null;
            }
            SamlAuthUser u = service.parseResponse(a);
            if (u == null || u.getUser() == null) {
                api.log().info("Username not available - not authorized.");
                return null;
            }
            api.log().info("Mapping roles");
            if (config.getBooleanProperty("saml_map_roles")) {
                Set<String>roles = mapRoles(u);
                if (roles.isEmpty()) {
                    api.log().info("No mapped roles - defaulting");
                    return AuthInfo.of(u.getUser(), Collections.singleton(config.getProperty("saml_default_role", "reader")));
                }
                api.log().info("Log in : " + u.getUser() + " with roles: " + roles);
                return AuthInfo.of(u.getUser(), roles);
            }
            api.log().info("Log in : " + u + " with default role: " + config.getProperty("saml_default_role", "reader"));
            return AuthInfo.of(u.getUser(), Collections.singleton(config.getProperty("saml_default_role", "reader")));
        } catch (InitializationException e) {
            api.log().error("Init Error: " + e);
            throw new AuthenticationException(e.toString());
        } catch (CertificateException e) {
            api.log().error("Cert Init Error: " + e);
            throw new AuthenticationException(e.toString());
        } catch (UnsupportedEncodingException e) {
            api.log().error("Can't decode SAML token: " + e);
            throw new AuthenticationException(e.toString());
        }
    }
}