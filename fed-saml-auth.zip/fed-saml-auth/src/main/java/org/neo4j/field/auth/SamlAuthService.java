package org.neo4j.field.auth;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Base64;
import javax.xml.namespace.QName;
import net.shibboleth.utilities.java.support.xml.XMLParserException;
import org.joda.time.DateTime;
import org.opensaml.core.config.InitializationException;
import org.opensaml.core.xml.XMLObjectBuilderFactory;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.UnmarshallingException;
import org.opensaml.core.xml.util.XMLObjectSupport;
import org.opensaml.saml.saml2.core.Assertion;
import org.opensaml.saml.saml2.core.Response;
import org.opensaml.saml.security.impl.SAMLSignatureProfileValidator;
import org.xml.sax.SAXException;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureException;
import org.opensaml.saml.saml2.core.Attribute;
import org.opensaml.saml.saml2.core.AttributeStatement;
import org.opensaml.saml.saml2.core.Audience;
import org.opensaml.saml.saml2.core.AudienceRestriction;
import org.opensaml.saml.saml2.core.Status;
import org.opensaml.saml.saml2.core.StatusMessage;
import org.opensaml.security.credential.CredentialSupport;
import org.opensaml.security.x509.BasicX509Credential;
import org.opensaml.xmlsec.signature.support.SignatureValidator;

public class SamlAuthService {
    private BasicX509Credential cred = null;
    private LoggingFacade log = null;
    private SamlAuthConfig config = null;
    private Status status = null;

    public void init(SamlAuthConfig c) throws InitializationException {
        config = c;
    }
    
    public void setLogger(org.neo4j.logging.Log x) {
        log = new LoggingFacade(x);
    }
    
    public void setLogger(com.neo4j.server.security.enterprise.auth.plugin.api.AuthProviderOperations.Log x) {
        log = new LoggingFacade(x);
    }
    
    public void setLogger() {
        log = new LoggingFacade(SamlAuthService.class);
    }
    
    public Status getStatus() {
        return this.status;
    }
    
    public BasicX509Credential getIdpPublicKey() {
        return cred;
    }

    public void setIdpPublicKey(FileInputStream is) throws CertificateException {
        CertificateFactory f = CertificateFactory.getInstance("X.509");
        X509Certificate c = (X509Certificate)f.generateCertificate(is);
        this.cred = CredentialSupport.getSimpleCredential(c, null);
    }

    public SamlAuthUser parseResponse(Assertion a) {
        SamlAuthUser user = new SamlAuthUser(config);

        if (config.getBooleanProperty("saml_use_NameID")) {
            String subject = a.getSubject().getNameID().getValue();
            user.setUser(subject);  // authenticated subject     
        }
        
        user.setUntil(a.getConditions().getNotOnOrAfter());
        user.setSession(a.getAuthnStatements().get(0).getSessionIndex());
        
        for (AttributeStatement as : a.getAttributeStatements()) {
            for (Attribute aa : as.getAttributes()) {
                int cnt = aa.getAttributeValues().size();
                if (cnt > 1) {
                    ArrayList<String> x = SamlAuthUtil.getAttributeValues(aa.getAttributeValues());
                    user.addAttribute(aa.getName(), x);
                }
                else if (cnt == 1) {
                    String v = SamlAuthUtil.getAttributeValue(aa.getAttributeValues().get(0));
                    user.addAttribute(aa.getName(), v);
                }
            }
        }
        return user;
    }
    
    public Assertion decodeSamlResponse(String encodedSamlStr, boolean validateSig) {
        try {
            byte[] decode = Base64.getDecoder().decode(encodedSamlStr);
            String decodedSAMLstr = new String(decode, "UTF-8"); // for UTF-8 encoding
            Response r = getResponse(decodedSAMLstr);
            if (r.getAssertions().isEmpty()) {
                log.error("No assertions!");
                Status s = r.getStatus();
                log.error("Status is::" + s.getStatusMessage().getMessage());
                this.status = s;
                return null;
            }
            Assertion samlAssertion = r.getAssertions().get(0);
            if (validateAssertion(samlAssertion) != true) {
                log.error("Assertion is Invalid!");

                
// TODO Status
                return null;
            }
            if (validateSig == true) {
                // See if there's a signature in the overall response
                if (r.getSignature() != null) {
                    log.info("Validating response");
                    validateResponseSignature(r);
                }
                else {
                    log.info("Validating assertions");
                    validateAssertionSignature(samlAssertion);
                }
            }
            log.info("Returning::" + samlAssertion);
            return samlAssertion;
        } catch (SignatureException ex) {
            log.error("Signature Exception Validating Response or Assertion :: ", ex);
        } catch (IOException ex) {
            log.error("IO Exception:: ", ex);
        } catch (XMLParserException | UnmarshallingException | SAXException ex) {
            log.error("Error parsing SAML Response or Assertion :: ", ex);
        } 
        return null;
    }
  
    private <T> T buildSAMLObject(final Class<T> clazz) {
        T object = null;
        try {
            XMLObjectBuilderFactory builderFactory = XMLObjectProviderRegistrySupport.getBuilderFactory();
            QName defaultElementName = (QName) clazz.getDeclaredField("DEFAULT_ELEMENT_NAME").get(null);
            object = (T) builderFactory.getBuilder(defaultElementName).buildObject(defaultElementName);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            throw new IllegalArgumentException("Could not create SAML object");
        }
        return object;
    }
    
    private void setStatus(String message) {
        StatusMessage sm = buildSAMLObject(StatusMessage.class);
        sm.setMessage(message);
        Status s = buildSAMLObject(Status.class);
        s.setStatusMessage(sm);
        this.status = s;
    }
    
    private boolean validateAssertion(Assertion a) {
        DateTime start = a.getConditions().getNotBefore();
        DateTime end = a.getConditions().getNotOnOrAfter();
        DateTime now = DateTime.now();
        log.debug("Date Now: " + now.toString() + ", Start: " + start.toString() + ", End: " + end.toString());
        if (!now.isAfter(start) || !now.isBefore(end)) {
            log.error("Assertion not valid for:: " + now.toString());
            this.setStatus("Assertion not valid -> Now: " + now.toString() + ", Start: " + start.toString() + ", End: " + end.toString());
            return false;
        }
        
        boolean isFor = false;
        for (AudienceRestriction aa : a.getConditions().getAudienceRestrictions()) {
            for (Audience au : aa.getAudiences()) {
                if (au.getAudienceURI().equals(config.getProperty("saml_sp_entity_id"))) {
                    isFor = true;
                }
            }
        }
        if (isFor == false) {
            this.setStatus("SAML Response not for: " + config.getProperty("saml_sp_entity_id"));
        }
        return isFor;
    }
    
  public Response getResponse(String samlResponse) 
    throws IOException, XMLParserException, UnmarshallingException, SAXException, SignatureException {
        Response response = (Response) XMLObjectSupport.unmarshallFromInputStream(
        XMLObjectProviderRegistrySupport.getParserPool(), new ByteArrayInputStream(samlResponse.getBytes()));
        return response;
  }
  
  public Assertion getAssertion(String samlResponse)
      throws IOException, XMLParserException, UnmarshallingException, SAXException, SignatureException {
        Response response = (Response) XMLObjectSupport.unmarshallFromInputStream(
        XMLObjectProviderRegistrySupport.getParserPool(), new ByteArrayInputStream(samlResponse.getBytes()));
        return response.getAssertions().get(0);
  }
  
  public void validateAssertionSignature(Assertion assertion) throws SignatureException {
        Signature signature = assertion.getSignature();
        if (signature == null) {
            throw new SignatureException("No Signature found in Assertion");
        }

        SAMLSignatureProfileValidator validator = new SAMLSignatureProfileValidator();
        validator.validate(assertion.getSignature());
        SignatureValidator.validate(assertion.getSignature(), cred);
        log.info("Completed Signature Validation");
    }
  
    public void validateResponseSignature(Response response) throws SignatureException {        
        Signature signature = response.getSignature();
        if (signature == null) {
            throw new SignatureException("No Signature found in response");
        }

        SAMLSignatureProfileValidator validator = new SAMLSignatureProfileValidator();
        validator.validate(signature);  // throws exception
        log.info("validating sig");
        SignatureValidator.validate(signature, cred);  // throws SignatureException
        log.info("Completed Signature Validation");
    }
  
//    private Assertion decryptAssertion(KeyInfoCredentialResolver skicr, EncryptedAssertion assertion)
//            throws DecryptionException {
//        Decrypter decrypter = new Decrypter(null, skicr, new InlineEncryptedKeyResolver());
//        return decrypter.decrypt(assertion);
//    }
    
}
