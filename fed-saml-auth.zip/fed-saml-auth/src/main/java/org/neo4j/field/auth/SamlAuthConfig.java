package org.neo4j.field.auth;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;
import org.apache.commons.io.FileUtils;

public class SamlAuthConfig {

    protected String filename = "saml.conf";
    protected Properties props = null;
    private static SamlAuthConfig _instance = null;
    private Path propsPath = null;

    private SamlAuthConfig() throws IOException {
        loadProperties(null);
    }

    private SamlAuthConfig(Path base) throws IOException {
        loadProperties(base);
    }

    public static synchronized SamlAuthConfig getInstance() throws IOException {
        if (_instance == null) {
            _instance = new SamlAuthConfig();
        }
        return _instance;
    }
    
    public static synchronized SamlAuthConfig getInstance(Path base) throws IOException {
        if (_instance == null) {
            _instance = new SamlAuthConfig(base);
        }
        return _instance;
    }

    protected void loadProperties(Path base) throws IOException {
        props = new Properties();
        try {
            if (base == null) {
                InputStream is = getClass().getClassLoader().getResourceAsStream(filename);
                props.load(is);
            }
            else {
                try (BufferedReader reader = Files.newBufferedReader(base)) {
                    props.load(reader);
                    propsPath = base;
                }
            }
        } catch (IOException e) {
            throw new IOException("error loading properties " + filename + ", " + e);
        }
    }

    public String getProperty(String key) {
        return getProperty(key, null);
    }

    public String getProperty(String key, String defaultVal) {
        return props.getProperty(key, defaultVal);
    }

    public boolean getBooleanProperty(String key) {
        return getBooleanProperty(key, false);
    }

    public boolean getBooleanProperty(String key, boolean defaultValue) {
        String value = _instance.getProperty(key);
        if (value == null) {
            return defaultValue;
        } else {
            return value.equalsIgnoreCase("yes") || value.equalsIgnoreCase("true") || value.equalsIgnoreCase("on");
        }
    }
    
    public String getFileProperty(String key) {
        String val = getProperty(key + ".contents", null);
        if (val != null) {
            return val;
        }
        try {
            String file = props.getProperty(key);
            Path p = propsPath.getParent();
            System.out.println("PP" + p);
            String nv = FileUtils.readFileToString(p.resolve(file).toFile(), "UTF-8");
            props.put(key + ".contents", nv);
            return nv;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    
    
    public InputStream getFilePropertyResourceAsStream(String key, String defaultValue) {
        String file = _instance.getProperty(key);
        if (file == null) {
            file = defaultValue;
        }
        try {
            InputStream is = getClass().getResourceAsStream(file); 
            return is;
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public InputStream getFilePropertyAsStream(String key) {
        String file = props.getProperty(key);
        Path p = propsPath.getParent();
        try {
            FileInputStream is = new FileInputStream(p.resolve(file).toString());
            return is;
        } catch(FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    // redo this!
    public HashMap<String,Object> getMultiProperty(String key) {
        HashMap<String, Object> val = (HashMap<String,Object>)props.get(key + ".contents");
        if (val != null) {
            return val;
        }
        String map = props.getProperty(key);
        HashMap<String, Object> m = new HashMap<>();
        for (String entry : map.split("(?!<(?:\\(|\\[)[^)\\]]+),(?![^(\\[]+(?:\\)|\\]))")) {
            String[] k = entry.split("=");
            if (k[1].trim().startsWith("[")) {
                ArrayList<String> vs = new ArrayList<>();
                for (String v : k[1].trim().substring(1, k[1].trim().length()-1).split(",")) {
                    vs.add(v.trim());
                }
                m.put(k[0].trim(), vs);
            }
            else {
                m.put(k[0].trim(), k[1].trim());
            }
        }
        return m;
    }

    public Properties getProperties() {
        return this.props;
    }
}
