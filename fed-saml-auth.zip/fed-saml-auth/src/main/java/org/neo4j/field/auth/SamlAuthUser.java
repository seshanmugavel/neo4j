package org.neo4j.field.auth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.joda.time.DateTime;

public class SamlAuthUser {

    private String username = null;
    private ArrayList<String> roles = new ArrayList<>();
    private Map<String, Object> attributes = new HashMap<>();
    private SamlAuthConfig config = null;
    private DateTime until = DateTime.now();
    private String sessionIndex = null;

    public SamlAuthUser(SamlAuthConfig c) {
        this.config = c;
    }

    public void addAttribute(String key, Object val) {
        this.attributes.put(key, val);
    }

    public String getUser() {
        if (this.config != null) {
            if (this.config.getBooleanProperty("saml_use_nameid")) {
                return username;
            }
            else {
                return (String)this.attributes.get(this.config.getProperty("saml_user_attribute"));
            }
        }
        return username;
    }

    public void setUser(String username) {
        this.username = username;
    }

    public String getEmail() {
        if (this.config != null) {
            return (String)this.attributes.get(this.config.getProperty("saml_email_attribute"));
        }
        return null;
    }

    public ArrayList<String> getRoles() {
        if (this.config != null) {
            return (ArrayList<String>)this.attributes.get(this.config.getProperty("saml_role_attribute"));
        }
        return roles;
    }

    public void addAllGroups(ArrayList<String> list) {
        roles.addAll(list);
    }
    
    public void setUntil(DateTime u) {
        this.until = u;
    }
    
    public DateTime getUntil() {
        return this.until;
    }
    
    public void setSession(String index) {
        this.sessionIndex = index;
    }
    
    public String getSession() {
        return this.sessionIndex;
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("User:: ").append(getUser()).append(this.attributes);
        return s.toString();
    }
}
