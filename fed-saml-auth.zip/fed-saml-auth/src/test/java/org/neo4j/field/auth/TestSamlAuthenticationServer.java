package org.neo4j.field.auth;

import com.google.common.collect.ImmutableMap;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Security;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import junit.framework.Assert;
import net.shibboleth.utilities.java.support.xml.SerializeSupport;
import org.junit.BeforeClass;
import org.junit.Test;
import org.apache.commons.io.FileUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.joda.time.DateTime;
import org.neo4j.driver.v1.*;
import org.neo4j.driver.v1.exceptions.AuthenticationException;
import org.neo4j.driver.v1.exceptions.ClientException;
import org.opensaml.saml.saml2.core.Assertion;
import org.opensaml.saml.saml2.core.Response;
import org.opensaml.saml.saml2.core.impl.ResponseMarshaller;
import org.w3c.dom.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestSamlAuthenticationServer {

    private final String configFile = "saml.conf";
    private final String pathMain = "src/main/resources";
    private final String pathTest = "src/test/resources";
    private final Logger log = LoggerFactory.getLogger(TestSamlAuthenticationServer.class);

    @BeforeClass
    public static void init() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
    }
    
    /**
     * test loading saml.conf from classpath
     */
    @Test
    public void testPropertiesLoadCP() {
        log.info("Loading Properties from Classpath");
        SamlAuthConfig c;
        try {
            c = SamlAuthConfig.getInstance();
            Assert.assertEquals("neo4j.cert", c.getProperty("saml_x509_certificate"));
        } catch (IOException ex) {
            log.error("Error loading properties", ex);
            Assert.assertTrue(false);
        }    
    }

    /**
     * test loading saml.conf from explicit dir
     */
    @Test
    public void testPropertiesLoadF() {
        log.info("Loading Properties from Dir");
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance(Paths.get(pathTest).resolve(configFile));
            Assert.assertEquals("neo4j.cert", y.getProperty("saml_x509_certificate"));
        } catch (IOException ex) {
            log.error("Error loading properties", ex);
            Assert.assertTrue(false);
        }
    }

    /**
     * test parsing of multi-props.
     */
    @Test
    public void testMultiProperties() {
        log.info("Testing multi-props");
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance(Paths.get(pathTest).resolve(configFile));
            log.info("MULTI:: " + y.getMultiProperty("saml_role_mapping"));
            Assert.assertTrue(y.getMultiProperty("saml_role_mapping").containsKey("users"));
        } catch (IOException e) {
            log.error("Error loading properties", e);
            Assert.assertTrue(false);
        }
        
    }
    
    /**
     * test valid signed assertion
     */
    @Test
    public void testSignedAssertion1() {
        log.info("Testing Signed Assertion #1");
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance(Paths.get(pathTest).resolve(configFile));
            SamlResponseGenerator rg = new SamlResponseGenerator();
            rg.setCreds((FileInputStream)y.getFilePropertyAsStream("saml_private_key"), (FileInputStream)y.getFilePropertyAsStream("saml_x509_certificate"));
            Response res = rg.createSAMLResponse("testuser11", new DateTime(), "password", null, "testissuer22", 30);
            ResponseMarshaller marshaller = new ResponseMarshaller();
            Element element = marshaller.marshall(res);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            SerializeSupport.writeNode(element, baos);
            String responseStr = new String(baos.toByteArray());
            log.info("Generated SAML Response::" + responseStr);
            
            String xe = Base64.getEncoder().encodeToString(responseStr.getBytes());
            
            SamlAuthService se = new SamlAuthService();
            se.setIdpPublicKey((FileInputStream)y.getFilePropertyAsStream("saml_x509_certificate"));
            se.init(y);
            se.setLogger();
            log.info("Validating");
            Assertion a = se.decodeSamlResponse(xe, true);
            Assert.assertNotNull(a);
            SamlAuthUser u = se.parseResponse(a);
            Assert.assertEquals("testuser11", u.getUser());
        } catch (Exception e) {
            System.out.println("Error::" + e);
            e.printStackTrace();
            Assert.assertFalse(true);
        }
    }
    
    /**
     * test invalid signed assertion
     */
    @Test
    public void testSignedAssertion2() {
        log.info("Testing Signed Assertion #2");
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance(Paths.get(pathTest).resolve(configFile));
            SamlResponseGenerator rg = new SamlResponseGenerator();
            rg.setCreds((FileInputStream)y.getFilePropertyAsStream("saml_private_key"), (FileInputStream)y.getFilePropertyAsStream("saml_x509_certificate"));
            Response res = rg.createSAMLResponse("testuser11", new DateTime(), "password", null, "testissuer22", 30);
            ResponseMarshaller marshaller = new ResponseMarshaller();
            Element element = marshaller.marshall(res);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            SerializeSupport.writeNode(element, baos);
            String responseStr = new String(baos.toByteArray());
            log.info("Generated SAML Response::" + responseStr);
            String mResp = responseStr.replaceAll("testuser11", "testuser22");  // modify it
            String xe = Base64.getEncoder().encodeToString(mResp.getBytes());
            
            SamlAuthService se = new SamlAuthService();
            se.setIdpPublicKey((FileInputStream)y.getFilePropertyAsStream("saml_x509_certificate"));
            se.init(y);
            se.setLogger();
            log.info("Validating");
            Assertion a = se.decodeSamlResponse(xe, true);
            Assert.assertNull(a);
        } catch (Exception e) {
            System.out.println("Error::" + e);
            e.printStackTrace();
            Assert.assertFalse(true);
        }
    }
    
    /**
     * test attribute statements
     */
    @Test
    public void testSignedAssertion3() {
        log.info("Testing Signed Assertion #3");
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance(Paths.get(pathTest).resolve(configFile));
            SamlResponseGenerator rg = new SamlResponseGenerator();
            rg.setCreds((FileInputStream)y.getFilePropertyAsStream("saml_private_key"), (FileInputStream)y.getFilePropertyAsStream("saml_x509_certificate"));
            HashMap atts = new HashMap();
            ArrayList e = new ArrayList();
            e.add("test@test.com");
            atts.put("email", e);
            ArrayList roles = new ArrayList();
            roles.add("users");
            roles.add("examplerole1");
            atts.put("rolemap", roles);
            Response res = rg.createSAMLResponse("testuser11", new DateTime(), "password", atts, "testissuer22", 30);
            ResponseMarshaller marshaller = new ResponseMarshaller();
            Element element = marshaller.marshall(res);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            SerializeSupport.writeNode(element, baos);
            String responseStr = new String(baos.toByteArray());
            log.info("Generated SAML Response::" + responseStr);
            String xe = Base64.getEncoder().encodeToString(responseStr.getBytes());
            
            SamlAuthService se = new SamlAuthService();
            se.setIdpPublicKey((FileInputStream)y.getFilePropertyAsStream("saml_x509_certificate"));
            se.init(y);
            se.setLogger();
            log.info("Validating");
            Assertion a = se.decodeSamlResponse(xe, true);
            Assert.assertNotNull(a);
            SamlAuthUser u = se.parseResponse(a);
            Assert.assertEquals("testuser11", u.getUser());
            Assert.assertEquals("test@test.com", u.getEmail());
            Assert.assertEquals(2,u.getRoles().size());
        } catch (Exception e) {
            System.out.println("Error::" + e);
            e.printStackTrace();
            Assert.assertFalse(true);
        }
    }
    
    @Test
    public void testConnection1() {
        try {
            Path p = Paths.get(pathTest).resolve("assertion_sig.xml");
            String assertion = FileUtils.readFileToString(p.toFile(), "UTF-8");
            String xe = Base64.getEncoder().encodeToString(assertion.getBytes());
            //Driver driver = GraphDatabase.driver( "bolt://localhost:7687", AuthTokens.basic( "test", xe ) );
            Map<String, Object> params = ImmutableMap.of("provider", "saml", "token", xe);
            Driver driver = GraphDatabase.driver( "bolt://ec2-3-80-231-63.compute-1.amazonaws.com:57687", AuthTokens.custom("test", "", "", "", params ) );
            //Driver driver = GraphDatabase.driver( "bolt://localhost:7687", AuthTokens.custom("test", "", "", "", params ) );
            StatementResult res = null;
            try ( Session session = driver.session() ) {
                res = session.run("CREATE (a:Test {name: 'test'})");
                log.info("TEST " + res);
                session.close();
                driver.close();
            } catch (ClientException ex ) {
                log.error("Error running:: " + ex.getMessage() );
            }
        } catch (IOException ex) {
            log.error("error:: ", ex);
        } catch (AuthenticationException ex) {
            log.error("error:: " + ex.getMessage());
            Assert.assertTrue(false);
        }
    } 
    
    @Test
    public void testConnection2() {
        try {
            Path p = Paths.get(pathTest).resolve("neo4jcert_signedresponse.xml");
            String assertion = FileUtils.readFileToString(p.toFile(), "UTF-8");
            String xe = Base64.getEncoder().encodeToString(assertion.getBytes());
            //Driver driver = GraphDatabase.driver( "bolt://localhost:7687", AuthTokens.basic( "test", xe ) );
            Map<String, Object> params = ImmutableMap.of("provider", "saml", "token", xe);
            Driver driver = GraphDatabase.driver( "bolt://ec2-3-80-231-63.compute-1.amazonaws.com:57687", AuthTokens.custom("test", "", "", "", params ) );
            //Driver driver = GraphDatabase.driver( "bolt://localhost:7687", AuthTokens.custom("test", "", "", "", params ) );
            StatementResult res = null;
            try ( Session session = driver.session() ) {
                res = session.run("CREATE (a:Test {name: 'test'})");
                log.info("TEST " + res);
                session.close();
                driver.close();
            } catch (ClientException ex ) {
                log.error("Error running:: " + ex.getMessage() );
            }
        } catch (IOException ex) {
            log.error("error:: ", ex);
        } catch (AuthenticationException ex) {
            log.error("error:: " + ex.getMessage());
            Assert.assertTrue(false);
        }
    } 
}
