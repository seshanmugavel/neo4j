package org.neo4j.field.auth;

import java.nio.file.Paths;
import java.security.Security;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.opensaml.core.config.InitializationService;
import org.opensaml.saml.saml2.core.AuthnRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestSamlRequest {
    private final String configFile = "saml.conf";
    private final String pathMain = "src/main/resources";
    private final String pathTest = "src/test/resources";
    private final Logger log = LoggerFactory.getLogger(TestSamlAuthenticationServer.class);

    @BeforeClass
    public static void init() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        InitializationService.initialize();
    }
    
    /**
     * test generating AuthNrequest.
     */
    @Test
    public void testRequest1() {
        log.info("Generate AuthN Req");
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance(Paths.get(pathTest).resolve(configFile));
            SamlRequest r = new SamlRequest();
            AuthnRequest x = r.buildAuthenticationRequest(y);
            log.info("Issuer:: " + x.getIssuer().getValue());
            Assert.assertEquals((String)y.getProperty("saml_sp_issuer_id"), x.getIssuer().getValue());
            String z = r.generateSAMLRequest(y, false);
            log.info("REQ::" + z);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.assertFalse(true);
        }
    }
    
    @Test
    public void TestMetadata() {
        log.info("Metadata Test");
        SamlRequest r = new SamlRequest();
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance(Paths.get(pathTest).resolve(configFile));
            String m = r.generateMetaData(y, false, false).getValue();
            log.info("Metadata::" + m);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.assertFalse(true);
        }
     
    }
    
}
