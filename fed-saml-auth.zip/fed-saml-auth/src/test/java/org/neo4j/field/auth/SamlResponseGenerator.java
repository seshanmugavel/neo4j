package org.neo4j.field.auth;

import org.apache.commons.io.IOUtils;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.StringReader;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.xml.namespace.QName;
import net.shibboleth.utilities.java.support.xml.SerializeSupport;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.joda.time.DateTime;
import org.opensaml.core.config.InitializationException;
import org.opensaml.core.config.InitializationService;
import org.opensaml.core.xml.XMLObjectBuilderFactory;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.MarshallingException;
import org.opensaml.core.xml.schema.XSString;
import org.opensaml.core.xml.schema.impl.XSStringBuilder;
import org.opensaml.saml.common.SAMLVersion;
import org.opensaml.saml.saml2.core.Assertion;
import org.opensaml.saml.saml2.core.Attribute;
import org.opensaml.saml.saml2.core.AttributeStatement;
import org.opensaml.saml.saml2.core.AttributeValue;
import org.opensaml.saml.saml2.core.AuthnContext;
import org.opensaml.saml.saml2.core.AuthnContextClassRef;
import org.opensaml.saml.saml2.core.AuthnStatement;
import org.opensaml.saml.saml2.core.Issuer;
import org.opensaml.saml.saml2.core.NameID;
import org.opensaml.saml.saml2.core.Response;
import org.opensaml.saml.saml2.core.Status;
import org.opensaml.saml.saml2.core.StatusCode;
import org.opensaml.saml.saml2.core.Subject;
import org.opensaml.saml.saml2.core.SubjectConfirmation;
import org.opensaml.saml.saml2.core.SubjectConfirmationData;
import org.opensaml.saml.saml2.core.impl.ResponseMarshaller;
import org.opensaml.security.credential.CredentialSupport;
import org.opensaml.security.x509.BasicX509Credential;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureConstants;
import org.opensaml.xmlsec.signature.support.SignatureException;
import org.opensaml.xmlsec.signature.support.Signer;
import org.w3c.dom.Element;

/**
 * generate SAML responses for testing.  adapted from:
 * https://github.com/rackerlabs/saml-generator
 */
public class SamlResponseGenerator {
    private BasicX509Credential cred = null;
    
    public Response createSAMLResponse(final String subjectId, final DateTime authenticationTime,
            final String credentialType, final HashMap<String, List<String>> attributes, String issuer, Integer samlAssertionDays) throws SignatureException {

        try {
            InitializationService.initialize();
            Signature sig = getSignature();
            Status status = getStatus();
            Issuer responseIssuer = null;
            Issuer assertionIssuer = null;
            Subject subject = null;
            AttributeStatement attributeStatement = null;
            if (issuer != null) {
                responseIssuer = getIssuer(issuer);
                assertionIssuer = getIssuer(issuer);
            }

            if (subjectId != null) {
                subject = getSubject(subjectId, samlAssertionDays);
            }

            if (attributes != null && attributes.size() != 0) {
                attributeStatement = getAttributeStatement(attributes);
            }

            AuthnStatement authnStatement = getAuthnStatement(authenticationTime);
            Assertion assertion = getAssertion(new DateTime(), subject, assertionIssuer, authnStatement, attributeStatement);
            Response response = getResponse(new DateTime(), responseIssuer, status, assertion);
            response.setSignature(sig);
            ResponseMarshaller marshaller = new ResponseMarshaller();
            Element element = marshaller.marshall(response);
            if (sig != null) {
                Signer.signObject(sig);
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            SerializeSupport.writeNode(element, baos);
            return response;
        } catch (InitializationException ie) {
            ie.printStackTrace();
            return null;
        } catch (MarshallingException me) {
            me.printStackTrace();
            return null;
        } catch (SignatureException se) {
            se.printStackTrace();
            return null;
        }
    }

    /**
     * pull in the credentials from separate PEM-encoded files.  same files as those generated for Neo4j.
     * @param keyFile
     * @param certFile
     * @throws FileNotFoundException
     * @throws CertificateException 
     */
    public void setCreds(FileInputStream keyFile, FileInputStream certFile) throws FileNotFoundException, CertificateException {
        CertificateFactory f = CertificateFactory.getInstance("X.509");
        X509Certificate c = (X509Certificate)f.generateCertificate(certFile);
        BufferedInputStream bis = new BufferedInputStream(keyFile);
        try {
            String contents = IOUtils.toString(keyFile, StandardCharsets.UTF_8);
            PemReader pemReader = new PemReader(new StringReader(contents));
            PemObject pemObject = pemReader.readPemObject();
            byte[] pemContent = pemObject.getContent();
            pemReader.close();
            PKCS8EncodedKeySpec encodedKeySpec = new PKCS8EncodedKeySpec(pemContent);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA", "BC");
            PrivateKey pk = keyFactory.generatePrivate(encodedKeySpec);
            this.cred = CredentialSupport.getSimpleCredential(c, pk);
	} catch (IOException e) {
            e.printStackTrace();
	} catch (NoSuchAlgorithmException ae) {
            ae.printStackTrace();
        } catch (InvalidKeySpecException ex) {
            ex.printStackTrace();
        } catch (NoSuchProviderException ex) {
            ex.printStackTrace();
        }
    }

    private Response getResponse(final DateTime issueDate, Issuer issuer, Status status, Assertion assertion) {
        Response response = buildSAMLObject(Response.class);
        response.setID(UUID.randomUUID().toString());
        response.setIssueInstant(issueDate);
        response.setVersion(SAMLVersion.VERSION_20);
        response.setIssuer(issuer);
        response.setStatus(status);
        response.getAssertions().add(assertion);
        return response;
    }

    private Assertion getAssertion(final DateTime issueDate, Subject subject, Issuer issuer, AuthnStatement authnStatement,
            AttributeStatement attributeStatement) {

        Assertion a = buildSAMLObject(Assertion.class);
        a.setID(UUID.randomUUID().toString());
        a.setIssueInstant(issueDate);
        a.setSubject(subject);
        a.setIssuer(issuer);
        if (authnStatement != null) {
            a.getAuthnStatements().add(authnStatement);
        }
        if (attributeStatement != null) {
            a.getAttributeStatements().add(attributeStatement);
        }
        return a;
    }
  
    private AuthnStatement getAuthnStatement(final DateTime issueDate) {
        AuthnContextClassRef cr = buildSAMLObject(AuthnContextClassRef.class);
        cr.setAuthnContextClassRef("urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport");
        AuthnContext ac = buildSAMLObject(AuthnContext.class);
        ac.setAuthnContextClassRef(cr);
        AuthnStatement st = buildSAMLObject(AuthnStatement.class);
        st.setAuthnInstant(issueDate);
        st.setAuthnContext(ac);
        return st;
    }
    
    private AttributeStatement getAttributeStatement(HashMap<String, List<String>> attributes) {
        AttributeStatement as = buildSAMLObject(AttributeStatement.class);
        if (attributes != null) {
            for (Map.Entry<String, List<String>> entry : attributes.entrySet()) {
                Attribute att = buildSAMLObject(Attribute.class);
                att.setName(entry.getKey());
                for (String value : entry.getValue()) {
                    XSStringBuilder stringBuilder = new XSStringBuilder();
                    XSString av = stringBuilder.buildObject(AttributeValue.DEFAULT_ELEMENT_NAME, XSString.TYPE_NAME);
                    av.setValue(value);
                    att.getAttributeValues().add(av);
                }

                as.getAttributes().add(att);
            }
        }
        return as;
    }

    private Issuer getIssuer(final String issuerName) {
        Issuer i = buildSAMLObject(Issuer.class);
        i.setValue(issuerName);
        return i;
    }

    private Subject getSubject(final String subjectId, final Integer days) {
        DateTime currentDate = new DateTime();
        if (days != null) {
            currentDate = currentDate.plusDays(days);
        }
        NameID nameId = buildSAMLObject(NameID.class);
        nameId.setValue(subjectId);
        nameId.setFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:persistent");
        SubjectConfirmationData sData = buildSAMLObject(SubjectConfirmationData.class);
        sData.setNotOnOrAfter(currentDate);
        SubjectConfirmation sc = buildSAMLObject(SubjectConfirmation.class);
        sc.setMethod("urn:oasis:names:tc:SAML:2.0:cm:bearer");
        sc.setSubjectConfirmationData(sData);
        Subject sub = buildSAMLObject(Subject.class);
        sub.setNameID(nameId);
        sub.getSubjectConfirmations().add(sc);
        return sub;
    }

    private Status getStatus() {
        StatusCode sc = buildSAMLObject(StatusCode.class);
        sc.setValue(StatusCode.SUCCESS);
        Status s = buildSAMLObject(Status.class);
        s.setStatusCode(sc);
        return s;
    }

    private Signature getSignature() {
        if (cred != null) {
            Signature signature = buildSAMLObject(Signature.class);
            signature.setSigningCredential(this.cred);
            signature.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA1);
            signature.setCanonicalizationAlgorithm(SignatureConstants.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);
            return signature;
        }
        return null;
    }
    
    private <T> T buildSAMLObject(final Class<T> clazz) {
        T object = null;
        try {
            XMLObjectBuilderFactory builderFactory = XMLObjectProviderRegistrySupport.getBuilderFactory();
            QName defaultElementName = (QName) clazz.getDeclaredField("DEFAULT_ELEMENT_NAME").get(null);
            object = (T) builderFactory.getBuilder(defaultElementName).buildObject(defaultElementName);
        } catch (IllegalAccessException e) {
            throw new IllegalArgumentException("Could not create SAML object");
        } catch (NoSuchFieldException e) {
            throw new IllegalArgumentException("Could not create SAML object");
        }
        return object;
    }
}
