package org.neo4j.field.auth;

import java.io.FileInputStream;
import java.nio.file.Paths;
import java.security.Security;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.opensaml.core.config.InitializationService;
import org.opensaml.saml.saml2.core.AuthnRequest;
import org.opensaml.saml.saml2.core.LogoutRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestSamlLogout {
    private final String configFile = "saml.conf";
    private final String pathMain = "src/main/resources";
    private final String pathTest = "src/test/resources";
    private final Logger log = LoggerFactory.getLogger(TestSamlLogout.class);

    @BeforeClass
    public static void init() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        InitializationService.initialize();
    }
    
    /**
     * test generating LogoutRequest.
     */
    @Test
    public void testLORequest1() {
        log.info("Generate Logout Req");
        try {
            SamlAuthConfig y = SamlAuthConfig.getInstance(Paths.get(pathTest).resolve(configFile));
            SamlRequest r = new SamlRequest();
            r.setCreds((FileInputStream)y.getFilePropertyAsStream("saml_private_key"), (FileInputStream)y.getFilePropertyAsStream("saml_x509_certificate"));
            LogoutRequest x = r.buildLogoutRequest(y, "test", "99");
            log.info("LO Reason:: " + x.getReason());
//            Assert.assertEquals((String)y.getProperty("saml_sp_issuer_id"), x.getIssuer().getValue());
//            String z = r.generateSAMLRequest(y, false);
//            log.info("REQ::" + z);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.assertFalse(true);
        }
    }
}
