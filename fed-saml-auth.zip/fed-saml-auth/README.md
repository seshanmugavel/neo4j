# SAMLv2 Auth

Plugin/Extension to implement a basic SAMLv2 authentication flow.
See the document below for the flows supported.

## Install

* `git clone git@github.com:neo-technology-field/fed-saml-auth.git`
* `mvn clean package`
* put target/saml-auth-1.x.jar into plugins directory
* put saml.conf into conf directory.  configure IDP urls, etc.
* put certificates/keys into conf directory for use with SAML. The following keys/certs are needed:
    * saml_x509_certificate - path to the public x.509 cert of the key used by the IDP to sign a SAML Response/Assertion
    * saml_private_key - path to the private key used by the Neo4j SP to sign the SAML Request sent to the IDP.
* edit neo4j.conf to specify properties that we pull as part of the db (early) startup process

        dbms.security.auth_providers=plugin-org.neo4j.field.auth.SamlAuthPlugin,native
        dbms.security.authentication_providers=plugin-org.neo4j.field.auth.SamlAuthPlugin,native
        dbms.security.authorization_providers=plugin-org.neo4j.field.auth.SamlAuthPlugin,native
        dbms.security.procedures.unrestricted=apoc.*,bloom.*
        dbms.security.http_auth_whitelist=/,.favicon.ico,/browser.*,/bloom.*,/saml.*
        dbms.unmanaged_extension_classes=org.neo4j.field.auth=/saml,com.neo4j.bloom.server=/bloom

* restart neo4j

## Usage

* Generate Metadata for SP

        /saml/auth/metadata

* Start auth flow

        /saml/auth/login

* Login to Neo4j Browser Directly (via SAML IDP)

        /saml/auth/browser

* Login to Neo4j Bloom Directly (via SAML IDP)

        /saml/auth/bloom

## Limitations & More Info

* 4.x only.

### Detailed Instructions
* https://docs.google.com/document/d/14RaPpeyG-ouoO6TrIjKlcif040finVMVgFmWQSv4Vm4/edit?usp=sharing


